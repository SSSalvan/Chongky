import serverless from "serverless-http";
import app from "/sleep.js";
// fart
export default serverless(app);